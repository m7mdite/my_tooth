import 'package:flutter/material.dart';

import 'colors_constant.dart';

class AppGradients {
  static LinearGradient get arcticFrostGradient => LinearGradient( // ✅ get بدل =
    colors: [
                      AppColors.surface,             // ✅ بدل white
                      AppColors.surface.withOpacity(0.9), // ✅ بدل white70
                      AppColors.primaryLightAccent,  // ✅
                      AppColors.primaryAccent,       // ✅ يتغير حسب الثيم



      // AppColors.background,
      // AppColors.primary,
      // AppColors.primaryLightAccent,
      // AppColors.primaryAccent,
    ],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}